This folder has an example implementation for random forest overed as a part of chapter 5 using Apache Mahout 0.9 distribution.
