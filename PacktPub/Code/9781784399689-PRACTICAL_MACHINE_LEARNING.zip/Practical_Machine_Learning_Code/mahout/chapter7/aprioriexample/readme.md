There are no direct APIs for implementing apriori based association rule based learning. FP Growth has a specific implementation for frequent pattern based association rules implementation.

This is a placeholder folder and implementation details will be added as and when supporting APIs are made available with the maout distributions

Reference to list of algorithms supported by mahout can be found here:
https://mahout.apache.org/users/basics/algorithms.html
