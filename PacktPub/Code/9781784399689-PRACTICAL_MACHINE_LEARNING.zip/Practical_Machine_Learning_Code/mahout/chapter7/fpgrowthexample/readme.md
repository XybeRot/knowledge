This folder has an example implementation for fp-growth algorithm using Apache Mahout 0.9 distribution covered as a part of chapter 7 association rule based learning methods
