There are no direct APIs for implementing Support Vector Machines algorithm. There are some alternative ways of solving this problem using Hadoop MapReduce.

This is a placeholder folder and implementation details will be added as and when supporting APIs are made available with the maout distributions

Reference to list of algorithms supported by mahout can be found here:
https://mahout.apache.org/users/basics/algorithms.html
