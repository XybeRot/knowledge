A ensemble of different distributed recommendation systems using Apache Mahout.
