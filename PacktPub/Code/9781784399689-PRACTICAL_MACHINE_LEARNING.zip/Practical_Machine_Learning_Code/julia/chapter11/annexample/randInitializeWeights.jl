# Practical Machine learning
# Artificial Neural Network
# Chapter 11

function randInitializeWeights(L_in, L_out)
   W = RANDINITIALIZEWEIGHTS(L_in, L_out)
  return W
end
