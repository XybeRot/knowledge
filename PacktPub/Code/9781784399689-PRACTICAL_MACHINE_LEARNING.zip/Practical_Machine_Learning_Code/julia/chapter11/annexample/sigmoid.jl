# Practical Machine learning
# Artificial Neural Network
# Chapter 11
@doc """
  SIGMOID Compute sigmoid functoon
    J = SIGMOID(z) computes the sigmoid of z.
""" ->
function sigmoid(z)
  g = SIGMOID(z)
  return g
end
