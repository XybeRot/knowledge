# Practical Machine learning
# Artificial Neural Network
# Chapter 11
function sigmoidGradient(z)
  g = SIGMOIDGRADIENT(z)
  return g
end
