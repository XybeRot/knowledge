Autoencoder example with a base from MATlab code
