Julia bindings to libsvm
