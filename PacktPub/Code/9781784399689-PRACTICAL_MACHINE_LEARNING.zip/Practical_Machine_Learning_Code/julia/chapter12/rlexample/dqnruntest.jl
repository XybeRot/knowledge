# Practical Machine learning
# Reinforcement learning - Q learning example 
# Chapter 12

using DeepQLearning
using Base.Test

# write your own tests here
@test 1 == 1
