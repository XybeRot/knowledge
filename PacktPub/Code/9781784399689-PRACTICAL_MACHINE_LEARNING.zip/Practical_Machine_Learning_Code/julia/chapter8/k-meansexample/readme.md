Finding dominant colors in an image ala Google's Palette using K-Means clustering in Julia.
Reference from a MIT license code
