Naive Bayes Classifier implementation with scikit-learn with the spambase dataset.

