This folder provides an implementation for fpgrowth using vanilla python libraries and not scikit-learn packages
