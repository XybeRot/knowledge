Reference from Andrew Ng example for reinforcement learning:
http://cs229.stanford.edu/notes/cs229-notes12.pdf

scikit-learn provides excellent tools for supervised and unsupervised learning but explicitly does not deal with reinforcement learning.
This example implementation is intended to compliment the functionality of scikit-learn.
