# Iris Dataset

This Dataset has been obtained from [UCI ML Repository](http://archive.ics.uci.edu/ml/datasets/Iris).
