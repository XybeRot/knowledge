# kNN using the scikit-learn package
A basic k-Nearest Neighbour implementation in python using the scikitlearn package.

# Usage
Look for code in `demo.py`.

# Dependencies
 - Numpy
 - Matplotlib
