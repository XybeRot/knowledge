cd /home/sunilag/spark-1.4.1-bin-hadoop2.6/bin
./spark-submit  /home/sunilag/Spark_Linear_Regression/ClickRate.py
