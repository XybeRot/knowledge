There are no explicit libraries avaialble in R for FP growth implementation. The folder is left as a place holder for implementing the same in future.
