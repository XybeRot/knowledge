BEFORE YOU BEGIN

you will need the following:

Python 3
sklearn (numpy, scipy)
matplotlib

theano
[theano installation instructions]
