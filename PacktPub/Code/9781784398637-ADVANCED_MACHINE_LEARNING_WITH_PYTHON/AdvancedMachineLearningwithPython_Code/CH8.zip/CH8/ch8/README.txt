Hi there!

This chapter's code runs through a number of powerful ensemble algorithms.

It requires no additional libraries (provided you have the libraries from preceding chapters) with one exception; the xgboost library is required!

This can be obtained through pip with no inconvenience. 

Good luck, and have fun!
