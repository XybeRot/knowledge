This chapter's code contains a number of simple scripts demonstrating the feature engineering techniques (lasso, rfe, eigenvector creation and the hash trick) discussed in this chapter. 

Due to limitations on data availability it was not possible to provide data to enable you to use the model discussed in Chapter 7. API scripts were provided should you wish to acquire data of your own.

This chapter's code requires one library; urllib (urllib2 for python 2.x users). urllib is split into three components (urllib.request, urllib.error and urllib.parse).
