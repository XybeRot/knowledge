main = do
  print $ map (^10) [10^10..10^10+10000]