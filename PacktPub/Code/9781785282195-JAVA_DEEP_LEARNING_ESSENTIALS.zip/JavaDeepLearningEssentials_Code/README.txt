Code files for chapter 1, 6, and 8 are not there in the bundle.

We'll implement deep learning algorithms using Lambda Expressions, hence Java 8
or above is required. Also, we'll use the Java library DeepLearning4J 0.4 or above.

You can also find the code files at https://github.com/PacktPublishing/Java-Deep-Learning-Essentials