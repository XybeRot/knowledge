Scripts are in the "cameo" folder.

Note that scipy is required. This requirement needs to be added to Chapter 1 in the next draft.

The managers.py script is unchanged since Chapter 2.