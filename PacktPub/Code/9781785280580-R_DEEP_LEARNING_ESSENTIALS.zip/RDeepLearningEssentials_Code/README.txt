The checkpoint.R file contains the commands to install the required R packages for each chapter.

Note that the code bundle contains some system path locations that are user-specific, which need to be changed according to the user's system path locations for the respective files.