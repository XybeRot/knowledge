"Unity Virtual Reality Projects" book files bundle
by Jonathan Linowes

These files include source assets that can be used with projects in the book, as referenced in the corresponding chapters. Also included are completed C# script files developed in the chapter projects.

Please report errors in the book directly to Packt Publishing. 
If you have any other questions or comments feel free to contact the author directly at jonathan@parkerhill.com or Twitter @linojon

